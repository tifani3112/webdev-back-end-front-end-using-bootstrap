<?php 
include "includes/config.php";
if(isset($_GET['hapuskabupaten']))
{
    $idkab = $_GET["hapuskabupaten"];
    mysqli_query($connection, "DELETE FROM kabupaten
        WHERE kabupatenKODE = '$idkab'");
    echo "<script>alert('DATA BERHASIL DIHAPUS');
        document.location='kabupaten.php'</script>";
}
