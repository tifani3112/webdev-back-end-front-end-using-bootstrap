<?php 
include "includes/config.php";
if(isset($_GET['hapus']))
{
    $provinsikode = $_GET["hapus"];
    mysqli_query($connection, "DELETE FROM provinsi
        WHERE provinsiID = '$provinsikode'");
    echo "<script>alert('DATA BERHASIL DIHAPUS');
        document.location='provinsi.php'</script>";
}